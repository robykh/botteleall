#!/bin/sh


ulang="y"

while [ $ulang = "y" ]
do

python visit.py -p +6285257457341 -c doge &>/dev/null&
sleep 30s
python visit.py -p +6289654527189 -c doge &>/dev/null&
sleep 30s
python visit.py -p +15056000255 -c doge &>/dev/null&
sleep 30s
python visit.py -p +15163248939 -c doge &>/dev/null&
sleep 30s
python visit.py -p +16314503140 -c doge &>/dev/null&
sleep 30s
python visit.py -p +15162596268 -c doge &>/dev/null&
sleep 30s
python visit.py -p +14235160761 -c doge &>/dev/null&
sleep 30s
python visit.py -p +15056008398 -c doge &>/dev/null&
sleep 30s
python visit.py -p +16808002509 -c doge &>/dev/null&
sleep 30s
python visit.py -p +16804441487 -c doge &>/dev/null&
sleep 30s
python visit.py -p +13159282613 -c doge &>/dev/null&
sleep 30s
python visit.py -p +16804440174 -c doge &>/dev/null&
sleep 30s
python visit.py -p +14233010245 -c doge &>/dev/null&
sleep 30s
python visit.py -p +14237288386 -c doge &>/dev/null&
sleep 30s
python visit.py -p +14237288548 -c doge &>/dev/null&
sleep 30s
python visit.py -p +14234362293 -c doge &>/dev/null&
sleep 30s
python visit.py -p +14233915156 -c doge &>/dev/null&
sleep 30s
python visit.py -p +14235211345 -c doge &>/dev/null&
sleep 30s
python visit.py -p +14237288468 -c doge &>/dev/null&
sleep 30s
python visit.py -p +14234915376 -c doge &>/dev/null&
sleep 30s
python visit.py -p +14234362784 -c doge &>/dev/null&
sleep 30s
python visit.py -p +14235290685 -c doge &>/dev/null&
sleep 30s
python visit.py -p +14234309047 -c doge &>/dev/null&
sleep 30s
python visit.py -p +14234915761 -c doge &>/dev/null&
sleep 1h
done

