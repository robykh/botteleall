#!/bin/sh


ulang="y"

while [ $ulang = "y" ]
do

python visit.py -p +6285257457341 -c ltc &>/dev/null&
sleep 10
python visit.py -p +6289654527189 -c ltc &>/dev/null&
sleep 10
python visit.py -p +15056000255 -c ltc &>/dev/null&
sleep 10
python visit.py -p +15163248939 -c ltc &>/dev/null&
sleep 10
python visit.py -p +16314503140 -c ltc &>/dev/null&
sleep 10
python visit.py -p +15162596268 -c ltc &>/dev/null&
sleep 10
python visit.py -p +14235160761 -c ltc &>/dev/null&
sleep 10
python visit.py -p +15056008398 -c ltc &>/dev/null&
sleep 10
python visit.py -p +16808002509 -c ltc &>/dev/null&
sleep 10
python visit.py -p +16804441487 -c ltc &>/dev/null&
sleep 10
python visit.py -p +13159282613 -c ltc &>/dev/null&
sleep 10
python visit.py -p +16804440174 -c ltc &>/dev/null&
sleep 10
python visit.py -p +14233010245 -c ltc &>/dev/null&
sleep 10
python visit.py -p +14237288386 -c ltc &>/dev/null&
sleep 10
python visit.py -p +14237288548 -c ltc &>/dev/null&
sleep 10
python visit.py -p +14234362293 -c ltc &>/dev/null&
sleep 10
python visit.py -p +14233915156 -c ltc &>/dev/null&
sleep 10
python visit.py -p +14235211345 -c ltc &>/dev/null&
sleep 10
python visit.py -p +14237288468 -c ltc &>/dev/null&
sleep 10
python visit.py -p +14234915376 -c ltc &>/dev/null&
sleep 10
python visit.py -p +14234362784 -c ltc &>/dev/null&
sleep 10
python visit.py -p +14235290685 -c ltc &>/dev/null&
sleep 10
python visit.py -p +14234309047 -c ltc &>/dev/null&
sleep 10
python visit.py -p +14234915761 -c ltc &>/dev/null&
sleep 10
python visit.py -p +19035465695 -c ltc &>/dev/null&
sleep 10
python visit.py -p +19034857417 -c ltc &>/dev/null&
sleep 10
python visit.py -p +12893355463 -c ltc &>/dev/null&
sleep 10
python visit.py -p +19713198740 -c ltc &>/dev/null&
sleep 10
python visit.py -p +18123075287 -c ltc &>/dev/null&
sleep 10
python visit.py -p +19032700688 -c ltc &>/dev/null&
sleep 10
python visit.py -p +14343218152 -c ltc &>/dev/null&
sleep 10
python visit.py -p +14433963821 -c ltc &>/dev/null&
sleep 2h
done

