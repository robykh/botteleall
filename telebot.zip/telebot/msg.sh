#!/bin/sh

ulang="y"

while [ $ulang = "y" ]
do

python msg.py +15163248939 &>/dev/null&
sleep 60
python msg.py +16314503140 &>/dev/null&
sleep 60
python msg.py +15162596268 &>/dev/null&
sleep 60
python msg.py +14235160761 &>/dev/null&
sleep 60
python msg.py +15056008398 &>/dev/null&
sleep 60
python msg.py +16808002509 &>/dev/null&
sleep 60
python msg.py +16804441487 &>/dev/null&
sleep 60
python msg.py +13159282613 &>/dev/null&
sleep 60
python msg.py +16804440174 &>/dev/null&
sleep 60
python msg.py +14233010245 &>/dev/null&
sleep 60
python msg.py +14237288386 &>/dev/null&
sleep 60
python msg.py +14237288548 &>/dev/null&
sleep 60
python msg.py +14234362293 &>/dev/null&
sleep 60
python msg.py +14233915156 &>/dev/null&
sleep 60
python msg.py +14235211345 &>/dev/null&
sleep 60
python msg.py +14237288468 &>/dev/null&
sleep 60
python msg.py +14234915376 &>/dev/null&
sleep 60
python msg.py +14234362784 &>/dev/null&
sleep 60
python msg.py +14235290685 &>/dev/null&
sleep 60
python msg.py +14234309047 &>/dev/null&
sleep 60
python msg.py +14234915761 &>/dev/null&
sleep 60
python msg.py +19035465695 &>/dev/null&
sleep 60
python msg.py +19034857417 &>/dev/null&
sleep 60
python msg.py +12893355463 &>/dev/null&
sleep 60
python msg.py +19713198740 &>/dev/null&
sleep 60
python msg.py +18123075287 &>/dev/null&
sleep 60
python msg.py +19032700688 &>/dev/null&
sleep 3600
done
